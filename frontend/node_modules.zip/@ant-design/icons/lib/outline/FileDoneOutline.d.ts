import { IconDefinition } from '../types';
declare const FileDoneOutline: IconDefinition;
export default FileDoneOutline;
