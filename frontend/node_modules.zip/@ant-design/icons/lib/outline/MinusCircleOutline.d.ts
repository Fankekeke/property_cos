import { IconDefinition } from '../types';
declare const MinusCircleOutline: IconDefinition;
export default MinusCircleOutline;
