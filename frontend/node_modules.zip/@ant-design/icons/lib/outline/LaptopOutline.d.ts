import { IconDefinition } from '../types';
declare const LaptopOutline: IconDefinition;
export default LaptopOutline;
