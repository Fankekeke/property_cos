import { IconDefinition } from '../types';
declare const PieChartOutline: IconDefinition;
export default PieChartOutline;
