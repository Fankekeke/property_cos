import { IconDefinition } from '../types';
declare const PlusCircleOutline: IconDefinition;
export default PlusCircleOutline;
