import { IconDefinition } from '../types';
declare const AntCloudOutline: IconDefinition;
export default AntCloudOutline;
