import { IconDefinition } from '../types';
declare const CloudUploadOutline: IconDefinition;
export default CloudUploadOutline;
