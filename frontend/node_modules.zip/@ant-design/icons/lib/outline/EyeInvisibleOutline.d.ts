import { IconDefinition } from '../types';
declare const EyeInvisibleOutline: IconDefinition;
export default EyeInvisibleOutline;
