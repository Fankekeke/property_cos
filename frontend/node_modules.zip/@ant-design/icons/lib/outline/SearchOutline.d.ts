import { IconDefinition } from '../types';
declare const SearchOutline: IconDefinition;
export default SearchOutline;
