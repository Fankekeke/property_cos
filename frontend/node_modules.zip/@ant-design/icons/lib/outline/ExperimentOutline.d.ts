import { IconDefinition } from '../types';
declare const ExperimentOutline: IconDefinition;
export default ExperimentOutline;
