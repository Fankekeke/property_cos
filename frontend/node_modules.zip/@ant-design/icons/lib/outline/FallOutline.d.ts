import { IconDefinition } from '../types';
declare const FallOutline: IconDefinition;
export default FallOutline;
