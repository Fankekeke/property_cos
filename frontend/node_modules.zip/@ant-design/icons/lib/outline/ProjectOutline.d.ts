import { IconDefinition } from '../types';
declare const ProjectOutline: IconDefinition;
export default ProjectOutline;
