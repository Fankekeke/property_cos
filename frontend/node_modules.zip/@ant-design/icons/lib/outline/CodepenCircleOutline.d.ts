import { IconDefinition } from '../types';
declare const CodepenCircleOutline: IconDefinition;
export default CodepenCircleOutline;
