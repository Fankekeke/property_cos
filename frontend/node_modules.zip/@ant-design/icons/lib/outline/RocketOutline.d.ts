import { IconDefinition } from '../types';
declare const RocketOutline: IconDefinition;
export default RocketOutline;
