import { IconDefinition } from '../types';
declare const CheckOutline: IconDefinition;
export default CheckOutline;
