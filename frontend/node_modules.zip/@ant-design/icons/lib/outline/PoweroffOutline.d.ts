import { IconDefinition } from '../types';
declare const PoweroffOutline: IconDefinition;
export default PoweroffOutline;
