import { IconDefinition } from '../types';
declare const RadiusBottomrightOutline: IconDefinition;
export default RadiusBottomrightOutline;
