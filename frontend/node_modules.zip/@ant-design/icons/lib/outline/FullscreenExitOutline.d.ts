import { IconDefinition } from '../types';
declare const FullscreenExitOutline: IconDefinition;
export default FullscreenExitOutline;
