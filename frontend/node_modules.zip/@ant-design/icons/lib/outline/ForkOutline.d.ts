import { IconDefinition } from '../types';
declare const ForkOutline: IconDefinition;
export default ForkOutline;
