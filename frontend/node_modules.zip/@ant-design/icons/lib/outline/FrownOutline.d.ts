import { IconDefinition } from '../types';
declare const FrownOutline: IconDefinition;
export default FrownOutline;
