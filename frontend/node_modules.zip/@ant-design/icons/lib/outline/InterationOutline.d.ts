import { IconDefinition } from '../types';
declare const InterationOutline: IconDefinition;
export default InterationOutline;
