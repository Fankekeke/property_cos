import { IconDefinition } from '../types';
declare const PaperClipOutline: IconDefinition;
export default PaperClipOutline;
