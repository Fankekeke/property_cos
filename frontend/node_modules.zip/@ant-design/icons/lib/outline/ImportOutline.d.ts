import { IconDefinition } from '../types';
declare const ImportOutline: IconDefinition;
export default ImportOutline;
