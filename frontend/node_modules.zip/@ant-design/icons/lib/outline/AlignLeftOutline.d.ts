import { IconDefinition } from '../types';
declare const AlignLeftOutline: IconDefinition;
export default AlignLeftOutline;
