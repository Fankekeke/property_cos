import { IconDefinition } from '../types';
declare const PhoneOutline: IconDefinition;
export default PhoneOutline;
