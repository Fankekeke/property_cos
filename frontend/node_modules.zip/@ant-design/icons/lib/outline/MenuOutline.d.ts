import { IconDefinition } from '../types';
declare const MenuOutline: IconDefinition;
export default MenuOutline;
