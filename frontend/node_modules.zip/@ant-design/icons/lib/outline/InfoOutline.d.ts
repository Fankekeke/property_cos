import { IconDefinition } from '../types';
declare const InfoOutline: IconDefinition;
export default InfoOutline;
