import { IconDefinition } from '../types';
declare const CoffeeOutline: IconDefinition;
export default CoffeeOutline;
