import { IconDefinition } from '../types';
declare const RadiusUpleftOutline: IconDefinition;
export default RadiusUpleftOutline;
