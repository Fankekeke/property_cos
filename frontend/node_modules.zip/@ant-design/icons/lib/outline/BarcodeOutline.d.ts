import { IconDefinition } from '../types';
declare const BarcodeOutline: IconDefinition;
export default BarcodeOutline;
