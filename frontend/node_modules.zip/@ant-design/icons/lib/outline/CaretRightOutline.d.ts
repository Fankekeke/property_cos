import { IconDefinition } from '../types';
declare const CaretRightOutline: IconDefinition;
export default CaretRightOutline;
