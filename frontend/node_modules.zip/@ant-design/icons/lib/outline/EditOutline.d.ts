import { IconDefinition } from '../types';
declare const EditOutline: IconDefinition;
export default EditOutline;
