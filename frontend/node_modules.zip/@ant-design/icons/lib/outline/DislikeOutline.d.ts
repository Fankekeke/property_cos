import { IconDefinition } from '../types';
declare const DislikeOutline: IconDefinition;
export default DislikeOutline;
