import { IconDefinition } from '../types';
declare const CrownOutline: IconDefinition;
export default CrownOutline;
