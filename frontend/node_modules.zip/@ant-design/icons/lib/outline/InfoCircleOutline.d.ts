import { IconDefinition } from '../types';
declare const InfoCircleOutline: IconDefinition;
export default InfoCircleOutline;
