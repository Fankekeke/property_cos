import { IconDefinition } from '../types';
declare const ArrowUpOutline: IconDefinition;
export default ArrowUpOutline;
