import { IconDefinition } from '../types';
declare const MenuFoldOutline: IconDefinition;
export default MenuFoldOutline;
