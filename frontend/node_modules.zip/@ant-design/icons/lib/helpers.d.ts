import { HelperRenderOptions, IconDefinition } from './types';
export declare function renderIconDefinitionToSVGElement(icon: IconDefinition, options?: HelperRenderOptions): string;
