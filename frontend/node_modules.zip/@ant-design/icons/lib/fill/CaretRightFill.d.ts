import { IconDefinition } from '../types';
declare const CaretRightFill: IconDefinition;
export default CaretRightFill;
