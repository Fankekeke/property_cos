import { IconDefinition } from '../types';
declare const IeCircleFill: IconDefinition;
export default IeCircleFill;
