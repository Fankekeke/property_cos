import { IconDefinition } from '../types';
declare const CaretUpFill: IconDefinition;
export default CaretUpFill;
