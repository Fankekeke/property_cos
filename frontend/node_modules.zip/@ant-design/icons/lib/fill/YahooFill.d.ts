import { IconDefinition } from '../types';
declare const YahooFill: IconDefinition;
export default YahooFill;
