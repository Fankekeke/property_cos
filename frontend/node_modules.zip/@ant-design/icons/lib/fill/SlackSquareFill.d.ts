import { IconDefinition } from '../types';
declare const SlackSquareFill: IconDefinition;
export default SlackSquareFill;
