import { IconDefinition } from '../types';
declare const TaobaoSquareFill: IconDefinition;
export default TaobaoSquareFill;
