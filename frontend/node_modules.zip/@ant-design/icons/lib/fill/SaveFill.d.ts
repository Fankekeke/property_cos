import { IconDefinition } from '../types';
declare const SaveFill: IconDefinition;
export default SaveFill;
