import { IconDefinition } from '../types';
declare const FunnelPlotFill: IconDefinition;
export default FunnelPlotFill;
