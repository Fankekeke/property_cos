import { IconDefinition } from '../types';
declare const CaretLeftFill: IconDefinition;
export default CaretLeftFill;
