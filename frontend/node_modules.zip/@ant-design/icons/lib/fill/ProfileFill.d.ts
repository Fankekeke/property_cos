import { IconDefinition } from '../types';
declare const ProfileFill: IconDefinition;
export default ProfileFill;
