import { IconDefinition } from '../types';
declare const FileZipFill: IconDefinition;
export default FileZipFill;
