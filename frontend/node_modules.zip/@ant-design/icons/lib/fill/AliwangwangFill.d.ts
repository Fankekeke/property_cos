import { IconDefinition } from '../types';
declare const AliwangwangFill: IconDefinition;
export default AliwangwangFill;
