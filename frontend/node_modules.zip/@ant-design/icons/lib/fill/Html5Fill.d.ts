import { IconDefinition } from '../types';
declare const Html5Fill: IconDefinition;
export default Html5Fill;
