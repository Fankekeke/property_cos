import { IconDefinition } from '../types';
declare const TrophyFill: IconDefinition;
export default TrophyFill;
