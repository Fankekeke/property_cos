import { IconDefinition } from '../types';
declare const GoldenFill: IconDefinition;
export default GoldenFill;
