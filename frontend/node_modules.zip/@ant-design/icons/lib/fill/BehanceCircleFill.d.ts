import { IconDefinition } from '../types';
declare const BehanceCircleFill: IconDefinition;
export default BehanceCircleFill;
