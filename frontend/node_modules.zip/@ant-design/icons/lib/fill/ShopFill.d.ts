import { IconDefinition } from '../types';
declare const ShopFill: IconDefinition;
export default ShopFill;
