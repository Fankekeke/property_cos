import { IconDefinition } from '../types';
declare const FacebookFill: IconDefinition;
export default FacebookFill;
