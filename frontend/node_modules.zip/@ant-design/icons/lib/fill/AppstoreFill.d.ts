import { IconDefinition } from '../types';
declare const AppstoreFill: IconDefinition;
export default AppstoreFill;
