import { IconDefinition } from '../types';
declare const RightSquareFill: IconDefinition;
export default RightSquareFill;
