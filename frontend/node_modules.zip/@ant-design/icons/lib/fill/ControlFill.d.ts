import { IconDefinition } from '../types';
declare const ControlFill: IconDefinition;
export default ControlFill;
