import { IconDefinition } from '../types';
declare const QuestionCircleFill: IconDefinition;
export default QuestionCircleFill;
