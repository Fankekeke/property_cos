import { IconDefinition } from '../types';
declare const MediumSquareFill: IconDefinition;
export default MediumSquareFill;
