import { IconDefinition } from '../types';
declare const UsbFill: IconDefinition;
export default UsbFill;
