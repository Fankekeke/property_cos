import { IconDefinition } from '../types';
declare const SmileFill: IconDefinition;
export default SmileFill;
