import { IconDefinition } from '../types';
declare const BookFill: IconDefinition;
export default BookFill;
