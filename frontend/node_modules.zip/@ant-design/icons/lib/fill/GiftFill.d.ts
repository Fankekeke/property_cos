import { IconDefinition } from '../types';
declare const GiftFill: IconDefinition;
export default GiftFill;
