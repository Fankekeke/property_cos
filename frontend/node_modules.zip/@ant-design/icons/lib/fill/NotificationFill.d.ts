import { IconDefinition } from '../types';
declare const NotificationFill: IconDefinition;
export default NotificationFill;
