import { IconDefinition } from '../types';
declare const ThunderboltFill: IconDefinition;
export default ThunderboltFill;
