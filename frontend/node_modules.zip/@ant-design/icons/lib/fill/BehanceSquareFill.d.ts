import { IconDefinition } from '../types';
declare const BehanceSquareFill: IconDefinition;
export default BehanceSquareFill;
