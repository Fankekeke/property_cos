import { IconDefinition } from '../types';
declare const ExperimentFill: IconDefinition;
export default ExperimentFill;
