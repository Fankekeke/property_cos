import { IconDefinition } from '../types';
declare const ContainerFill: IconDefinition;
export default ContainerFill;
