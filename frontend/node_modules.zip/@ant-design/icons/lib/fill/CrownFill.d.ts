import { IconDefinition } from '../types';
declare const CrownFill: IconDefinition;
export default CrownFill;
