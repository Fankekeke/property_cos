import { IconDefinition } from '../types';
declare const ExclamationCircleFill: IconDefinition;
export default ExclamationCircleFill;
