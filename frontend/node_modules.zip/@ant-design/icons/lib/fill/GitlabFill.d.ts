import { IconDefinition } from '../types';
declare const GitlabFill: IconDefinition;
export default GitlabFill;
